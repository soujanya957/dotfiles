-- Keymaps are automatically loaded on the VeryLazy event
-- Default keymaps that are always set: https://github.com/LazyVim/LazyVim/blob/main/lua/lazyvim/config/keymaps.lua
-- Add any additional keymaps here

vim.api.nvim_set_keymap("i", "jj", "<Esc>", { noremap = false })

local keymap = vim.keymap

-- general keymap
keymap.set("i", "jk", "<ESC>")

keymap.set("n", "<leader>nh", ":nohl<CR>")

keymap.set("n", "x", '"_x')

keymap.set("n", "<leader>+", "<C-a>")
keymap.set("n", "<leader>-", "<C-x>")

keymap.set("n", "<leader>sv", "<C-w>v") -- split window vertically
keymap.set("n", "<leader>sh", "<C-w>h") -- split window horizontally
keymap.set("n", "<leader>se", "<C-w>=") -- split window equally
keymap.set("n", "<leader>sx", ":close<CR>") -- close window

keymap.set("n", "<leader>to", ":tabnew<CR>") -- open new tab
keymap.set("n", "<leader>tx", ":tabclose<CR>") -- close tab
keymap.set("n", "<leader>tn", ":tabn<CR>") -- go to next tab
keymap.set("n", "<leader>tp", ":tabp<CR>") -- go to previous tab

-- <leader>yz : open yazi at current file
vim.keymap.set("n", "<leader>yz", function()
  require("yazi").yazi()
end, { desc = "Open yazi at current file" })

-- <leader>yw : open yazi in nvim's working directory
vim.keymap.set("n", "<leader>yw", function()
  require("yazi").yazi({ cwd = vim.fn.getcwd() })
end, { desc = "Open yazi in working directory" })

-- <leader>yr : resume last yazi session (toggle)
vim.keymap.set("n", "<leader>yr", function()
  require("yazi").yazi({ toggle = true })
end, { desc = "Resume last yazi session" })

-- <leader>yh : show yazi help (when yazi is open)
vim.keymap.set("n", "<leader>yh", function()
  vim.api.nvim_feedkeys(vim.api.nvim_replace_termcodes("<F1>", true, false, true), "n", false)
end, { desc = "Show yazi help (when yazi is open)" })
